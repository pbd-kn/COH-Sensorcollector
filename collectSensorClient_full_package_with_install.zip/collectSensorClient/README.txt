INSTALLATIONSHINWEISE FÜR Raspberry Pi:

1. ZIP auf Raspberry Pi kopieren:
   scp collectSensorClient.zip pi@raspberrypi:/home/pi/

2. Auf dem Pi einloggen und entpacken:
   cd /home/pi
   unzip collectSensorClient.zip
   cd collectSensorClient

3. collect.php testen:
   php collect.php

4. Systemd-Service einrichten:
   sudo cp collect.service /etc/systemd/system/
   sudo systemctl daemon-reload
   sudo systemctl enable collect.service
   sudo systemctl start collect.service

5. Status prüfen:
   sudo systemctl status collect.service

Nach einem Reboot läuft das Skript automatisch.
