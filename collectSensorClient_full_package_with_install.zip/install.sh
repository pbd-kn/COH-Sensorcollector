#!/bin/bash

set -e

echo "📦 Entpacke collectSensorClient.zip..."
unzip -o collectSensorClient.zip -d collectSensorClient

echo "🛠️  Installiere systemd Service..."
sudo cp collectSensorClient/collect.service /etc/systemd/system/

echo "🔄 systemd neu laden..."
sudo systemctl daemon-reexec
sudo systemctl daemon-reload

echo "✅ Service aktivieren und starten..."
sudo systemctl enable collect.service
sudo systemctl start collect.service

echo "📋 Service-Status:"
sudo systemctl status collect.service --no-pager
